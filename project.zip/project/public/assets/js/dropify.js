$(function() {
  'use strict';

  $('#myDropify').dropify();
  $('#myDropifyfront').dropify();
  $('#myDropifyback').dropify();
});